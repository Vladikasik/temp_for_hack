import { describe, expect, it } from 'vitest'

describe('Hi', () => {
  it('should works', () => {
    expect(1 + 1).toEqual(2)
  })
})
