# Download file to disk

Example that shows how to work with disk access and how to link several Wasm modules into a service.

# Build & deploy it

```shell
./deploy.sh
```

# Call it

```shell
fldist run_air -p download.air -d '{"service": "f7db6966-2d75-4424-812e-85e2ec5cb61b"}'
```
