#!/bin/sh

(cd producer; ./build.sh)
(cd consumer; ./build.sh)